Matrix number: A0105649

In this task I've followed lab instruction to draw degree 3 Bezier Curve.

I have used all 3 kinds of transformation. Formular learned on lecture was used to draw the curve.

I have modified the function a bit in case the exactly same submission form everyone makes it boring:
	1. When C is pressed, if modification is necessary, the program shows 2 curves, one red and one gray one. The red one is modified one with C1 continuity while the
		grey one is original. Thus, a comparasion can be simply achieved.
	
	2. 8 vector for a single curve makes me feel uncomfortable when number of curves getting large(Trypophobia). As a reasult, I draw 8 vectors for the whole graph.

	3. For object, I use the same algorithm. This makes it fun when you try to randomly click the screen --- ErHuLuanZis will jumping around the screen
*I believe these modifications show my ability to finish the original task a more:)

Last but not least, the coolest thing is still "mind-ontrolling" ErHuLuanZi!